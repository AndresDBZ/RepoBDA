-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: tutorias
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `docente`
--

DROP TABLE IF EXISTS `docente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `docente` (
  `id_docente` int NOT NULL,
  `nom_docente` varchar(10) DEFAULT NULL,
  `ape_docente` varchar(15) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `registro_doc` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_docente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docente`
--

LOCK TABLES `docente` WRITE;
/*!40000 ALTER TABLE `docente` DISABLE KEYS */;
INSERT INTO `docente` VALUES (1,'Roberto','Mendoza','roberto.mendoza@uni.edu','3001234567','2025-08-27 01:34:16'),(2,'Elena','Vasquez','elena.vasquez@uni.edu','3002345678','2025-08-27 01:34:16'),(3,'Miguel','Rios','miguel.rios@uni.edu','3003456789','2025-08-27 01:34:16'),(4,'Carmen','Ortega','carmen.ortega@uni.edu','3004567890','2025-08-27 01:34:16'),(5,'Javier','Silva','javier.silva@uni.edu','3005678901','2025-08-27 01:34:16'),(6,'Isabel','Paredes','isabel.paredes@uni.edu','3006789012','2025-08-27 01:34:16'),(7,'Ricardo','Navarro','ricardo.navarro@uni.edu','3007890123','2025-08-27 01:34:16'),(8,'Gabriela','Campos','gabriela.campos@uni.edu','3008901234','2025-08-27 01:34:16'),(9,'Fernando','Cordoba','fernando.cordoba@uni.edu','3009012345','2025-08-27 01:34:16'),(10,'Patricia','Miranda','patricia.miranda@uni.edu','3010123456','2025-08-27 01:34:16'),(11,'Hector','Vega','hector.vega@uni.edu','3011234567','2025-08-27 01:34:16'),(12,'Adriana','Fernandez','adriana.fernandez@uni.edu','3012345678','2025-08-27 01:34:16'),(13,'Raul','Nunez','raul.nunez@uni.edu','3013456789','2025-08-27 01:34:16'),(14,'Silvia','Mendoza','silvia.mendoza@uni.edu','3014567890','2025-08-27 01:34:16'),(15,'Eduardo','Rios','eduardo.rios@uni.edu','3015678901','2025-08-27 01:34:16'),(16,'Veronica','Ortega','veronica.ortega@uni.edu','3016789012','2025-08-27 01:34:16'),(17,'Roberto','Silva','roberto.silva@uni.edu','3017890123','2025-08-27 01:34:16'),(18,'Mariana','Paredes','mariana.paredes@uni.edu','3018901234','2025-08-27 01:34:16'),(19,'Carlos','Navarro','carlos.navarro@uni.edu','3019012345','2025-08-27 01:34:16'),(20,'Laura','Campos','laura.campos@uni.edu','3020123456','2025-08-27 01:34:16'),(21,'Andres','Cordoba','andres.cordoba@uni.edu','3021234567','2025-08-27 01:34:16'),(22,'Natalia','Miranda','natalia.miranda@uni.edu','3022345678','2025-08-27 01:34:16'),(23,'Diego','Vega','diego.vega@uni.edu','3023456789','2025-08-27 01:34:16'),(24,'Sofia','Fernandez','sofia.fernandez@uni.edu','3024567890','2025-08-27 01:34:16'),(25,'Juan','Nunez','juan.nunez@uni.edu','3025678901','2025-08-27 01:34:16'),(26,'Maria','Mendoza','maria.mendoza@uni.edu','3026789012','2025-08-27 01:34:16'),(27,'Pedro','Rios','pedro.rios@uni.edu','3027890123','2025-08-27 01:34:16'),(28,'Ana','Ortega','ana.ortega@uni.edu','3028901234','2025-08-27 01:34:16'),(29,'Luis','Silva','luis.silva@uni.edu','3029012345','2025-08-27 01:34:16'),(30,'Carolina','Paredes','carolina.paredes@uni.edu','3030123456','2025-08-27 01:34:16');
/*!40000 ALTER TABLE `docente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `docente_materia`
--

DROP TABLE IF EXISTS `docente_materia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `docente_materia` (
  `id_docente` int NOT NULL,
  `id_materia` int NOT NULL,
  PRIMARY KEY (`id_docente`,`id_materia`),
  KEY `id_materia` (`id_materia`),
  CONSTRAINT `docente_materia_ibfk_1` FOREIGN KEY (`id_docente`) REFERENCES `docente` (`id_docente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `docente_materia_ibfk_2` FOREIGN KEY (`id_materia`) REFERENCES `materia` (`id_materia`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docente_materia`
--

LOCK TABLES `docente_materia` WRITE;
/*!40000 ALTER TABLE `docente_materia` DISABLE KEYS */;
INSERT INTO `docente_materia` VALUES (1,1),(11,1),(20,1),(21,1),(28,1),(2,2),(12,2),(22,2),(3,3),(13,3),(23,3),(4,4),(13,4),(14,4),(23,4),(24,4),(30,4),(5,5),(15,5),(19,5),(21,5),(25,5),(29,5),(6,6),(15,6),(16,6),(25,6),(26,6),(7,7),(12,7),(16,7),(17,7),(22,7),(26,7),(27,7),(8,8),(11,8),(18,8),(28,8),(9,9),(18,9),(19,9),(21,9),(27,9),(29,9),(10,10),(14,10),(20,10),(24,10),(30,10),(1,11),(2,12),(3,13),(4,14),(23,14),(5,15),(6,16),(25,16),(7,17),(17,17),(22,17),(26,17),(27,17),(8,18),(28,18),(9,19),(29,19),(10,20),(24,20),(30,20);
/*!40000 ALTER TABLE `docente_materia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estudiantes`
--

DROP TABLE IF EXISTS `estudiantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estudiantes` (
  `id_estudiante` int NOT NULL,
  `nom_estudiante` varchar(10) DEFAULT NULL,
  `ape_estudiante` varchar(15) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `registro_est` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_estudiante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estudiantes`
--

LOCK TABLES `estudiantes` WRITE;
/*!40000 ALTER TABLE `estudiantes` DISABLE KEYS */;
INSERT INTO `estudiantes` VALUES (1,'Alejandro','Gutierrez','alejandro.gutierrez@uni.edu','3101234567','2025-08-27 01:34:16'),(2,'Valentina','Rojas','valentina.rojas@uni.edu','3102345678','2025-08-27 01:34:16'),(3,'Santiago','Mendoza','santiago.mendoza@uni.edu','3103456789','2025-08-27 01:34:16'),(4,'Isabella','Perez','isabella.perez@uni.edu','3104567890','2025-08-27 01:34:16'),(5,'Mateo','Hernandez','mateo.hernandez@uni.edu','3105678901','2025-08-27 01:34:16'),(6,'Camila','Garcia','camila.garcia@uni.edu','3106789012','2025-08-27 01:34:16'),(7,'Nicolas','Torres','nicolas.torres@uni.edu','3107890123','2025-08-27 01:34:16'),(8,'Sofia','Ramirez','sofia.ramirez@uni.edu','3108901234','2025-08-27 01:34:16'),(9,'Samuel','Diaz','samuel.diaz@uni.edu','3109012345','2025-08-27 01:34:16'),(10,'Emma','Vargas','emma.vargas@uni.edu','3110123456','2025-08-27 01:34:16'),(11,'Daniel','Castro','daniel.castro@uni.edu','3111234567','2025-08-27 01:34:16'),(12,'Lucia','Ortega','lucia.ortega@uni.edu','3112345678','2025-08-27 01:34:16'),(13,'Jeronimo','Silva','jeronimo.silva@uni.edu','3113456789','2025-08-27 01:34:16'),(14,'Mariana','Navarro','mariana.navarro@uni.edu','3114567890','2025-08-27 01:34:16'),(15,'David','Rios','david.rios@uni.edu','3115678901','2025-08-27 01:34:16'),(16,'Valeria','Campos','valeria.campos@uni.edu','3116789012','2025-08-27 01:34:16'),(17,'Sebastian','Fernandez','sebastian.fernandez@uni.edu','3117890123','2025-08-27 01:34:16'),(18,'Gabriela','Mora','gabriela.mora@uni.edu','3118901234','2025-08-27 01:34:16'),(19,'Tomas','Cordoba','tomas.cordoba@uni.edu','3119012345','2025-08-27 01:34:16'),(20,'Renata','Vega','renata.vega@uni.edu','3120123456','2025-08-27 01:34:16'),(21,'Juan','Paredes','juan.paredes@uni.edu','3121234567','2025-08-27 01:34:16'),(22,'Antonella','Nunez','antonella.nunez@uni.edu','3122345678','2025-08-27 01:34:16'),(23,'Emiliano','Miranda','emiliano.miranda@uni.edu','3123456789','2025-08-27 01:34:16'),(24,'Sara','Lopez','sara.lopez@uni.edu','3124567890','2025-08-27 01:34:16'),(25,'Miguel','Martinez','miguel.martinez@uni.edu','3125678901','2025-08-27 01:34:16'),(26,'Catalina','Gomez','catalina.gomez@uni.edu','3126789012','2025-08-27 01:34:16'),(27,'Joaquin','Suarez','joaquin.suarez@uni.edu','3127890123','2025-08-27 01:34:16'),(28,'Daniela','Acosta','daniela.acosta@uni.edu','3128901234','2025-08-27 01:34:16'),(29,'Andres','Bermudez','andres.bermudez@uni.edu','3129012345','2025-08-27 01:34:16'),(30,'Salome','Santos','salome.santos@uni.edu','3130123456','2025-08-27 01:34:16');
/*!40000 ALTER TABLE `estudiantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materia`
--

DROP TABLE IF EXISTS `materia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `materia` (
  `id_materia` int NOT NULL,
  `nombre_materia` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_materia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materia`
--

LOCK TABLES `materia` WRITE;
/*!40000 ALTER TABLE `materia` DISABLE KEYS */;
INSERT INTO `materia` VALUES (1,'Cálculo '),(2,'Física'),(3,'Química'),(4,'Biología '),(5,'Programación I'),(6,'Bases de Datos'),(7,'Redes'),(8,'Estadística'),(9,'Algoritmos '),(10,'ÉticaProfesiona'),(11,'CálculoIntegral'),(12,'Electromagnetis'),(13,'QuímicaOrgánica'),(14,'Genética'),(15,'ProgramaciónII'),(16,'BasesdeDatos'),(17,'Informática'),(18,'Inferencial'),(19,'AnalisisAl'),(20,'Deontología');
/*!40000 ALTER TABLE `materia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas`
--

DROP TABLE IF EXISTS `notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas` (
  `id_nota` int NOT NULL,
  `id_materia` int DEFAULT NULL,
  `nota` float DEFAULT NULL,
  `id_estudiante` int DEFAULT NULL,
  PRIMARY KEY (`id_nota`),
  KEY `id_materia` (`id_materia`),
  KEY `id_estudiante` (`id_estudiante`),
  CONSTRAINT `notas_ibfk_1` FOREIGN KEY (`id_materia`) REFERENCES `materia` (`id_materia`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notas_ibfk_2` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id_estudiante`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas`
--

LOCK TABLES `notas` WRITE;
/*!40000 ALTER TABLE `notas` DISABLE KEYS */;
INSERT INTO `notas` VALUES (1,1,4.2,1),(2,2,3.9,2),(3,3,4.1,3),(4,4,3.6,4),(5,5,4.5,5),(6,6,3.8,6),(7,7,4.7,7),(8,8,3.4,8),(9,9,4.3,9),(10,10,3.7,10),(11,11,4,11),(12,12,4.5,12),(13,13,3.5,13),(14,14,4.4,14),(15,15,4.8,15),(16,16,3.2,16),(17,17,4.2,17),(18,18,3.6,18),(19,19,4.6,19),(20,20,3.3,20),(21,1,4.1,21),(22,2,3.8,22),(23,3,4.4,23),(24,4,3.1,24),(25,5,4.7,25),(26,6,3.5,26),(27,7,4,27),(28,8,3.4,28),(29,9,4.3,29),(30,10,3.6,30),(31,11,4.2,1),(32,12,3.9,2),(33,13,4.5,3),(34,14,3.7,4),(35,15,4.6,5),(36,16,3.8,6),(37,17,4.1,7),(38,18,3.5,8),(39,19,4.4,9),(40,20,3.6,10);
/*!40000 ALTER TABLE `notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tutorias`
--

DROP TABLE IF EXISTS `tutorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tutorias` (
  `id_tutoria` int NOT NULL,
  `tema` varchar(15) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `id_docente` int DEFAULT NULL,
  `id_estudiante` int DEFAULT NULL,
  PRIMARY KEY (`id_tutoria`),
  KEY `id_docente` (`id_docente`),
  KEY `id_estudiante` (`id_estudiante`),
  CONSTRAINT `tutorias_ibfk_1` FOREIGN KEY (`id_docente`) REFERENCES `docente` (`id_docente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tutorias_ibfk_2` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id_estudiante`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tutorias`
--

LOCK TABLES `tutorias` WRITE;
/*!40000 ALTER TABLE `tutorias` DISABLE KEYS */;
INSERT INTO `tutorias` VALUES (1,'LimitesDerivada','2024-03-15','10:00:00',1,1),(2,'Leyes de Newton','2024-03-15','11:00:00',2,2),(3,'Ecuaciones','2024-03-16','09:30:00',3,3),(4,'ADN y ARN','2024-03-16','14:00:00',4,4),(5,'FundamentosPy','2024-03-18','15:00:00',5,5),(6,'ConsultasSQL','2024-03-18','08:00:00',6,6),(7,'Conf TCP/IP','2024-03-19','16:00:00',7,7),(8,'Probabilidad','2024-03-19','13:00:00',8,8),(9,'AnálisisAlgorit','2024-03-20','09:00:00',9,9),(10,'ÉticaInvestiga','2024-03-20','10:30:00',10,10),(11,'IntegralesDefi','2024-03-21','11:30:00',11,11),(12,'Ondas y Sonido','2024-03-21','12:00:00',12,12),(13,'CompuestosOrgá','2024-03-22','08:30:00',13,13),(14,'Microorganismo','2024-03-22','09:45:00',14,14),(15,'EstructurasCon','2024-03-25','14:15:00',15,15),(16,'Normalización','2024-03-25','16:20:00',16,16),(17,'Enrutamiento','2024-03-26','10:00:00',17,17),(18,'Regresión','2024-03-26','11:00:00',18,18),(19,'Complejidad','2024-03-27','15:40:00',19,19),(20,'Bioética','2024-03-27','16:30:00',20,20),(21,'Trigonométrica','2024-03-28','09:00:00',21,21),(22,'CamposElectrom','2024-03-28','13:30:00',22,22),(23,'Química','2024-03-29','08:00:00',23,23),(24,'ClasificaciónA','2024-03-29','10:00:00',24,24),(25,'POO','2024-04-01','11:00:00',25,25),(26,'Entidad-Relaci','2024-04-01','15:30:00',26,26),(27,'VLANs y Switch','2024-04-02','17:00:00',27,27),(28,'Hipótesis','2024-04-02','09:15:00',28,28),(29,'TeoríaGrafos','2024-04-03','14:50:00',29,29),(30,'Ética Laboral','2024-04-03','13:00:00',30,30);
/*!40000 ALTER TABLE `tutorias` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-26 21:28:11
